// w12 engagement rules (results/w12-engage.md). Decoded ladder deaths (contest x2, monolith): 60 of 79 fatal fights
// started with no ally within 4 tiles, 74 of 79 at half health or more, 78 of 79 with no gems carried. The rules stop a
// lone champion from taking or walking into an even fight; they leave every other decision to the v2 flow.
//  E1 disengage (pre hook): enemies within P_ENG_RADIUS >= 1 + allies within 4: step to the nearest visible ally or
//     the spawn (a melee champion strikes first: it may move and attack in one turn, GameRules "A champion turn").
//  E2 hot-zone leash (after resolve_target): while alone, a target within P_HOT_RADIUS of an enemy seen in the last
//     P_HOT_ROUNDS rounds is dropped for that long and another group is chosen.
//  E3 group move (contest only): champions may share a solo group, so the team farms as one body.
#include <cambc.h>
#include "bot.h"
#include "util.h"
#include "params.h"
#include <algorithm>

using cambc::vec2;
using cambc::team;

static constexpr int kEngRadius = P_ENG_RADIUS, kHotRadius = P_HOT_RADIUS, kHotRounds = P_HOT_ROUNDS;

bool Bot::engage_pre(const TurnView& v, std::vector<cambc::champion>& enemies,
                     const std::vector<cambc::champion>& allies) {
    auto& me = cambc::self();
    allies4 = 0;
    for (const auto& a : allies) if (!(a == me) && tile_distance(v.pos, a.position()) <= 4) ++allies4;
    if (enemies.empty()) return false;
    std::vector<vec2> foes;
    int nearest = 1 << 20;
    for (const auto& e : enemies) {
        if (e.health() <= 0) continue;
        const vec2 p = e.position();
        const int d = tile_distance(v.pos, p);
        if (d < nearest) nearest = d;
        if (d <= kEngRadius) foes.push_back(p);
    }
    // w12b: avoid contact, never run from it. A melee chaser moves and hits in the same turn (GameRules, "A champion
    // turn"), so leaving a fight that has started only gives free hits (h2h trace: Varg fled 10 rounds and died).
    if (nearest < P_ENG_CONTACT) return false;
    if (foes.empty() || 1 + allies4 > static_cast<int>(foes.size())) return false;   // numbers on our side: fight
    if (retreating || ally_spawn.is_set(v.pos)) return false;                         // the health retreat / spawn heal
    if (me.gem_count() > 0)   // a carrier beside an altar submits (damage does not interrupt a tribute)
        for (auto a : altars) if (tile_distance(v.pos, a) <= cambc::constants::submit_gems_range) return false;
    // Finish a lone, nearly dead enemy in attack range while healthy.
    if (foes.size() == 1 && me.health() >= 0.5f * me.max_health())
        for (const auto& e : enemies)
            if (e.health() > 0 && e.health() < 0.25f * e.max_health() && me.attack_tiles().is_set(e.position())) return false;
    if (!me.can_move()) return false;
    holding = -1;
    const int r = step_to_friends(foes, allies);
    ++disengages;
    {   // the sighting that made us back off marks nearby groups hot for E2
        int best = 1 << 20;
        for (const auto& e : enemies) if (e.health() > 0) { const int d = tile_distance(v.pos, e.position()); if (d < best) { best = d; hot_pos = e.position(); } }
        hot_round = v.round;
    }
    if (r == 0) return true;
    return false;   // at the ally already or no step: the normal enemy rules take the turn
}

// E2: called after resolve_target and the Plan target hook.
void Bot::engage_target(const TurnView& v) {
    if (target < 0 || allies4 > 0 || holding == target || v.round - hot_round > kHotRounds) return;
    if (min_distance(v.pos, groups[target].tiles) <= 2) return;   // already there: v2's contested rules decide
    if (min_distance(hot_pos, groups[target].tiles) > kHotRadius) return;
    const int t = target;
    groups[t].excluded_until = std::max(groups[t].excluded_until, hot_round + kHotRounds);
    for (std::size_t i = 0; i < groups.size(); ++i)   // every group near the sighting, not only the target
        if (min_distance(hot_pos, groups[i].tiles) <= kHotRadius)
            groups[i].excluded_until = std::max(groups[i].excluded_until, hot_round + kHotRounds);
    target = choose_target(v, t);
    wait_rounds = 0;
    wait_tank = 0;
    ++leashes;
}
