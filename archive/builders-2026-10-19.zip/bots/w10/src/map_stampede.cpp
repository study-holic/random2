// map_stampede.cpp: stampede plan (w10, results/w10-contested.md). The map's only gem source is one 6-Elk + 6-gem-cluster
// group on the symmetry axis (east edge, 360 gems a capture); the other 12 groups are gold clusters.
// P_W10_STAMPEDE bits: 2 = a squad may also take the other squad's claimed gem group (squads.cpp, other_claim);
// 4 = the health retreat counts only camps for which this champion is the nearest champion (bot.cpp incoming_nearest);
// 8 = a contested gem group is only left for a gem group (gem_alt); 16 = shop trip at P_W10_SHOP_GOLD carried gold;
// 32 = Tavi buys in the field. Default 2|4|8 (V6). Gem-first targeting without gold (tested as bit 1) was dropped:
// 7/12 and 6/12 against v2's 11/12 at salt 0.
#include "plan.h"
#include "bot.h"
#include "params.h"

#ifndef P_W10_STAMPEDE
#define P_W10_STAMPEDE (2 | 4 | 8)
#endif
#ifndef P_W10_SHOP_GOLD
#define P_W10_SHOP_GOLD 300
#endif

namespace Plan {

static void stampede_init(Bot& b) {
    if (P_W10_STAMPEDE & 2) b.share_gem_claim = true;
    if (P_W10_STAMPEDE & 4) b.nearest_incoming = true;
    if (P_W10_STAMPEDE & 8) b.gem_alt = true;
    if (P_W10_STAMPEDE & 16) b.shop_gold = P_W10_SHOP_GOLD;
    b.field_shop = (P_W10_STAMPEDE & 32) != 0;
}

void setup_stampede(MapPlan& p) { if (P_W10_STAMPEDE) p.init = stampede_init; }

}  // namespace Plan
