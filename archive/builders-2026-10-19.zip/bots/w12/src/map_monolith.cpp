// map_monolith.cpp: monolith plan. w12: engagement rules E1-E2 (engage.cpp); otherwise v4.14 behaviour.
#include "plan.h"
#include "bot.h"

namespace Plan {

void setup_monolith(MapPlan& p) {
    p.init = [](Bot& b) { b.engage = true; };
}

}  // namespace Plan
