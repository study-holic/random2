// map_contest.cpp: contest plan. w12: engagement rules E1-E3 (engage.cpp); otherwise v4.14 behaviour.
#include "plan.h"
#include "bot.h"

namespace Plan {

void setup_contest(MapPlan& p) {
    p.init = [](Bot& b) { b.engage = true; b.group_move = true; };
}

}  // namespace Plan
