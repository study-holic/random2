// v4.14 = v4.13 + opening assignment on maps with 5+ qualifying groups (expanse); EXP-083
#define P_OPENING_ASSIGN 1

// w12all: engagement rules E1+E2 on every map
#define P_ENGAGE_ALL 1
