// denial.cpp (w11): conversion-denial layer over v2.
// P_DENY_LOG: print one line per visible enemy tribute channel (measurement only, no behaviour change).
// P_LOCK_BUY (step 1), P_LOCK_DROP (step 2), P_INTERRUPT (step 3); P_FOCUS_RULE 1 (step 4) lives in enemies.cpp.
// Rules relied on (docs/rules/GameRules.md): "Altar locks are a consumable you can purchase for 10g, and carry one at
// a time"; "Place on an altar within two tiles"; "An altar lock blocks opposing tributes but allows its owner's team
// to tribute. Placing it cancels existing tribute channels at that altar. Three basic attacks remove it."; "Tribute
// ... damage does not stop it, but stun, death or a new altar lock does."
// SDK (sdk/cpp/cambc.h): champion::is_submitting_gems() (state bit), champion::gem_count() (require_runtime: any
// visible champion), champion::remaining_channel_time(), champion::consumables()[consumable_type::altar_lock].use(tile),
// champion::buy(consumable_type), champion::can_buy(consumable_type), vision::altar_locks().
#include <cambc.h>
#include "bot.h"
#include "util.h"
#include "params.h"
#include <iostream>

using cambc::vec2;
using cambc::team;

void Bot::init_denial() {
    altars_all = cambc::map::altars().positions();
    stun_range = -1;
    try {
        for (const auto& ab : cambc::self().abilities())
            if (ab.is_cc() && ab.can_target_enemies()) stun_range = std::max(stun_range, static_cast<int>(ab.get<cambc::ability_cc>().range));
    } catch (...) {}
}

bool Bot::stun_ready() const {
    try {
        for (const auto& ab : cambc::self().abilities())
            if (ab.is_cc() && ab.can_target_enemies() && ab.is_ready()) return true;
    } catch (...) {}
    return false;
}

int Bot::nearest_altar_all(vec2 p, int& dist) const {
    int best = -1; dist = 1 << 20;
    for (std::size_t i = 0; i < altars_all.size(); ++i) {
        const int d = tile_distance(p, altars_all[i]);
        if (d < dist) { dist = d; best = static_cast<int>(i); }
    }
    return best;
}

bool Bot::carrying_lock() const {
    try { return cambc::self().consumables()[cambc::consumable_type::altar_lock].count() > 0; } catch (...) { return false; }
}

// One line per enemy seen channelling a tribute: round, enemy handle, type, carried gems, channel left, altar,
// my distance to the enemy and to its altar, my slot, lock carried, stun ready.
void Bot::deny_log(const TurnView& v, const std::vector<cambc::champion>& enemies) {
    for (const auto& e : enemies) {
        bool sub = false;
        try { sub = e.is_submitting_gems(); } catch (...) { continue; }
        if (!sub) continue;
        int gems = -1, rem = -1;
        try { gems = static_cast<int>(e.gem_count()); } catch (...) {}
        try { rem = e.remaining_channel_time(); } catch (...) {}
        const vec2 ep = e.position();
        int ad = 0;
        const int ai = nearest_altar_all(ep, ad);
        const vec2 alt = ai >= 0 ? altars_all[ai] : vec2(-1, -1);
        std::cout << "TRIB r" << v.round << " e" << static_cast<unsigned>(static_cast<cambc::handle_champion_t>(e))
                  << " t" << static_cast<int>(e.champion_name()) << " g" << gems << " rem" << rem
                  << " a" << alt.x << "," << alt.y << " de" << tile_distance(v.pos, ep) << " da" << tile_distance(v.pos, alt)
                  << " me" << ally_index << " L" << (carrying_lock() ? 1 : 0) << " S" << (stun_ready() ? 1 : 0)
                  << " sr" << stun_range << '\n';
    }
}

// ---- step 1: buy a lock on every shop visit (after the shards) ------------------------------------------------------
void Bot::buy_lock() {
    if (!P_LOCK_BUY) return;
    auto& me = cambc::self();
    try {
        const auto L = cambc::consumable_type::altar_lock;
        if (me.gold_count() < L.cost()) return;
        if (me.consumables()[L].count() > 0) return;
        if (me.can_buy(L)) {
            me.buy(L); ++locks_bought;
            if (P_DENY_EVT && locks_bought <= 3) std::cout << "BUYLOCK r" << cambc::round_number() << " me" << ally_index << " gold" << me.gold_count() << '\n';
        }
    } catch (...) {}
}

// Place the carried lock on altar `a` (within 2 tiles). Skips an altar that already holds a lock or where a visible
// ally is channelling a tribute (the rule "placing it cancels existing tribute channels at that altar" does not say
// whose). Free of the move and attack allowances as far as the rules say (consumables only need inventory).
bool Bot::place_lock(cambc::vec2 a, const std::vector<cambc::champion>& allies, const std::vector<cambc::altar_lock>& locks) {
    auto& me = cambc::self();
    for (const auto& l : locks) if (l.position() == a) return false;
    for (const auto& al : allies) {
        if (al == me) continue;
        try { if (al.is_submitting_gems() && tile_distance(al.position(), a) <= cambc::constants::submit_gems_range) return false; } catch (...) {}
    }
    try {
        const bool m0 = me.can_move(), a0 = me.can_attack();
        if (me.consumables()[cambc::consumable_type::altar_lock].use(a)) {
            ++locks_used;
            if (P_DENY_EVT) std::cout << "LOCK r" << cambc::round_number() << " me" << ally_index << " a" << a.x << "," << a.y
                                      << " mv" << m0 << me.can_move() << " at" << a0 << me.can_attack() << " n" << locks_used << '\n';
            return true;
        }
    } catch (...) {}
    return false;
}

// ---- steps 2 and 3a: lock drops (free action, the turn goes on) --------------------------------------------------------
void Bot::lock_drops(const TurnView& v, const std::vector<cambc::champion>& enemies, const std::vector<cambc::champion>& allies) {
    if (!P_LOCK_DROP && !P_INTERRUPT) return;
    bool near = false;
    for (auto a : altars_all) if (tile_distance(v.pos, a) <= 2) { near = true; break; }
    if (!near || !carrying_lock()) return;
    std::vector<cambc::altar_lock> locks;
    try { locks = cambc::vision::altar_locks(); } catch (...) { return; }
    if (P_INTERRUPT)   // 3a: an enemy channelling beside an altar within 2 tiles: lock that altar (cancels the channel)
        for (const auto& e : enemies) {
            bool sub = false;
            try { sub = e.is_submitting_gems(); } catch (...) { continue; }
            if (!sub) continue;
            for (auto a : altars_all)
                if (tile_distance(v.pos, a) <= 2 && tile_distance(e.position(), a) <= cambc::constants::submit_gems_range
                    && place_lock(a, allies, locks)) { ++interrupts_lock; return; }
        }
    if (P_LOCK_DROP)
        for (auto a : altars_all)
            if (tile_distance(v.pos, a) <= 2 && place_lock(a, allies, locks)) return;
}

// ---- step 3b: stun or hit an enemy mid-tribute (the turn is used when an action was taken) -------------------------------
bool Bot::interrupt(const TurnView& v, const std::vector<cambc::champion>& enemies) {
    if (!P_INTERRUPT || enemies.empty()) return false;
    auto& me = cambc::self();
    const cambc::champion* foe = nullptr;
    int foe_g = -1;
    for (const auto& e : enemies) {
        bool sub = false;
        try { sub = e.is_submitting_gems() && e.health() > 0; } catch (...) { continue; }
        if (!sub) continue;
        int g = 0;
        try { g = static_cast<int>(e.gem_count()); } catch (...) {}
        if (g > foe_g) { foe_g = g; foe = &e; }
    }
    if (foe == nullptr) return false;
    const vec2 ep = foe->position();
    auto try_stun = [&]() {
        if (!me.can_cast()) return false;
        for (const auto& ab : me.abilities()) {
            if (!ab.is_cc() || !ab.can_target_enemies() || !ab.is_ready()) continue;
            try {
                if (ab.valid_tiles().is_set(ep) && ab.use(*foe)) {
                    ++interrupts_stun;
                    if (P_DENY_EVT) std::cout << "STUN r" << v.round << " me" << ally_index << " g" << foe_g << '\n';
                    return true;
                }
            } catch (...) {}
        }
        return false;
    };
    bool acted = try_stun();
    if (attack_if_in_range(*foe)) {
        if (foe->is_visible()) reset_and_attack_again(*foe);
        acted = true; ++interrupts_hit;
        if (P_DENY_EVT) std::cout << "HIT r" << v.round << " me" << ally_index << " g" << foe_g << '\n';
    }
    if (acted) return true;
    // Out of reach: step towards it when it is close, we are healthy, and no other enemy stands next to us.
    const int reach = std::max(std::max(1, static_cast<int>(me.attack_range())), stun_ready() ? stun_range : 0);
    const int d = tile_distance(v.pos, ep);
    if (retreating || d > reach + P_INTERRUPT_CHASE || me.health() < me.max_health() * 0.5f || !me.can_move()) return false;
    auto goals = tiles_around(ep, reach);
    goals.set(ep, false);
    if (!move_towards_closest(static_block, camp_static, goals)) return false;
    if (!foe->is_visible()) return true;
    try_stun();
    if (foe->is_visible() && attack_if_in_range(*foe)) {
        if (foe->is_visible()) reset_and_attack_again(*foe);
        ++interrupts_hit;
        if (P_DENY_EVT) std::cout << "HIT r" << v.round << " me" << ally_index << " g" << foe_g << " step\n";
    }
    return true;
}
