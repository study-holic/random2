// v4.14 = v4.13 + opening assignment on maps with 5+ qualifying groups (expanse); EXP-083
#define P_OPENING_ASSIGN 1
// w11 denial layer (denial.cpp): steps 1+2+3
#define P_DENY_LOG 0
#define P_LOCK_BUY 1
#define P_LOCK_DROP 1
#define P_INTERRUPT 0
