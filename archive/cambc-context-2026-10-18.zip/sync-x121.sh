#!/bin/sh
# copy sources to the workspace and make the debug copy
cd /c/Users/willi/OneDrive/Desktop/cambc-context
rm -rf bots/expanse-runner/src bots/dbg-expanse-runner/src
mkdir -p bots/expanse-runner bots/dbg-expanse-runner
cp -r cambc-context/bots/expanse-runner/src bots/expanse-runner/src
cp -r cambc-context/bots/expanse-runner/src bots/dbg-expanse-runner/src
sed -i 's/#define P_RUN_DBG 0/#define P_RUN_DBG 1/' bots/dbg-expanse-runner/src/util.h
