#!/bin/sh
export PATH="$PATH:/c/Users/willi/AppData/Roaming/Python/Python313/Scripts" CAMBC_OFFLINE=1
cd /c/Users/willi/OneDrive/Desktop/cambc-context/cambc-context
python tools/compare.py scr-packs expanse-runner --base-tag x10c --cand-tag xrc --opps tact-on,focus2,v2,v5-stack,v5-two,v4-12,v3a,centre-v3b,starter-python,v1 --maps "80" --jobs 1 --cells > results/exp121-confirm.txt 2> ../x121c.err
python tools/compare.py scr-packs expanse-runner --base-tag x10h --cand-tag xrh --opps v3b,v3c,v4-2,v4-6,v4-9,v4-11,v3d,v4-3a --maps "80" --jobs 1 --cells > results/exp121-heldout.txt 2> ../x121h.err
python tools/compare.py scr-packs expanse-runner --base-tag x10s --cand-tag xrs --opps v4-8,v3d,v4-3a --maps "30 31 40 41 50 50b 71 80 90" --jobs 1 --cells > results/exp121-54.txt 2> ../x121s.err
echo done > ../x121.done
