# Sprint 1 final four hours: pre-registered plan (written 18 October, about 20:15 BST)

Hard stop for development: **22:45**. Upload by **23:00**. Nothing new is started after **22:15**.

## Rules against confirmation bias (fixed now, before any game)

1. The decision rules below and in `roundrobin.py` are final. Nobody edits a threshold after a game has run, and nobody re-runs a failed arm with changed settings.
2. Old local results and old-pool ladder records count as no evidence for collision, corners, expanse, interlock, lanes, and packs, whose layouts changed.
3. Candidate drafts come from two external sources fixed in advance: the rank-1 team's drafts (set 1) and the top-30 modal drafts (set 2). Nobody picks champions by browsing results.
4. The current behaviour wins every tie.
5. One agent applies each rule and pastes its output verbatim into `experiments/log.md` with a timestamp.

## Files

- `mapid.h`: identifies all 17 maps (and the six originals) from dimensions and camp composition. `mapid::current_map()` works in the draft instance and in play instances and caches its result.
- `draft.cpp`: drop-in replacement for `bots/v418b-cand/src/draft.cpp`. `P_DRAFT_SET 0` reproduces the v4.18b lists exactly; `1` and `2` are the two templates; `P_SET_<MAP>` overrides one map. Rows and expanse keep the v4.18b drafts in every set.
- `roundrobin.py`: plays sets 0, 1, and 2 against each other on every map and side, applies the rule, and prints the `P_SET_<MAP>` lines.

Tested here with cambc 2.2.2 on the 17 supplied files: every map is identified correctly, set 0 matches v4.18b on every map, and a full round-robin takes about 2.5 minutes with starter-level bots.

## Timeline

| Time (BST) | Step | Exit |
|---|---|---|
| 20:15 to 20:30 | 0. `cambc maps pull`; confirm the 17 files; copy `v418b-cand` to `s0`, `s1`, `s2` with the new `draft.cpp` and `mapid.h`; `P_DRAFT_SET` 0, 1, 2 in each `params_override.h`; build all three | Three builds |
| 20:30 to 21:00 | 1. `python roundrobin.py --bots s0 s1 s2 --maps "maps/*.map26a" --out rr` | `rr/params_override_draft.h` |
| 21:00 to 22:15 | 2. Map toggles, each judged by its rule below, each gated with `mapid::current_map()` so other maps are unchanged | Pass or fail per toggle |
| 22:15 to 22:45 | 3. Assemble the release (draft overrides plus passing toggles); farming-pace guard on the existing panel | Ship or drop the last addition once |
| 22:45 to 23:00 | Bundle, hash, user uploads; v4.18b stays as rollback | Active on the site |
| After upload | Roll back on bot errors or crashes; no other trigger | |

## Step 2 toggles and their rules

**2a. Expanse runner on the replacement expanse (two elks per stack).** Build `s0` with `P_RUNNER 0` (its draft then becomes Vendetta, C&I, Stellar, the v4.17 expanse draft). Play runner-on against runner-off on expanse, both sides, and the expanse cells of the panel. Keep the runner when it wins head-to-head 2-0, or when it splits 1-1 with panel gems per 100 rounds at least equal and runner deaths at most 0.5 a game. Otherwise ship `P_RUNNER 0`.

**2b. Squads on 3- and 4-body rosters.** `P_SQUAD_MIN_ROSTER 5` may switch squads off wherever the roster has fewer than five bodies: every 3-pick map and the 4-pick interlock draft without C&I. [Hypothesis; confirm in `squads.cpp` first, two minutes.] If confirmed, and the macro appears in no `#if`, set `#define P_SQUAD_MIN_ROSTER (mapid::is_contact_map(mapid::current_map()) ? 3 : 5)`. Play the candidate against the base on the contact maps, both sides. Adopt when the candidate wins at least 60 per cent of those games and the step 3 guard passes.

**2c. Contest Monolith siege (`bots/v418-contest`, EXP-129: local contest wins 0 to 9 of 20).** Port its contest code behind `mapid::current_map() == MapId::contest` and keep `P_SET_CONTEST 0`. Include it when it wins at least one of two head-to-head games on contest against the base and the step 3 guard passes. Divergence on other maps is acceptable within the guard.

## Step 3 guard (farming pace)

Run compare.py of the release against `v418b-cand` on the existing 17-map panel. Ship when total wins fall by at most 3 and no single map loses 3 or more wins. On failure, drop the most recent toggle and run the guard once more; on a second failure ship the draft overrides alone.

## Prompt for the Claude Code lead session

```
Read FINAL-4H-PLAN.md and follow it exactly; its rules are pre-registered and may not be changed.
Copy bots/v418b-cand to bots/s0, bots/s1, bots/s2. Replace src/draft.cpp with the supplied draft.cpp
and add src/mapid.h. In each params_override.h set P_DRAFT_SET to 0, 1 and 2 respectively. If the build
fails on is_gem_cluster/is_gold_cluster/is_monolith, use camp.kind() == cambc::camp_type::<type> instead.
Run: python roundrobin.py --bots s0 s1 s2 --maps "maps/*.map26a" --out rr
Paste the full table into experiments/log.md, then do steps 2a, 2b, 2c in that order, stopping new work at
22:15 BST. Assemble the release at 22:15, run the step 3 guard, and stop all development at 22:45.
Prepare the bundle and its sha256 for my upload; keep v4.18b as rollback. Report each step's rule outcome
in one line as it finishes.
```
