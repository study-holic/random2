// Draft v4.19: map-identified preference lists for the 17-map pool of 18 October.
// P_DRAFT_SET selects the default list family:
//   0 = v4.18b lists, byte-for-byte the shipped logic (legacy_prefs below)
//   1 = rank-1 template (Intercontinental Fish drafts, evidence L11052)
//   2 = field-modal template (top-30 modal drafts per map, top-100 pick shares on new maps)
// Per-map overrides: define P_SET_<MAP> (for example P_SET_CORNERS_V2 1) in params_override.h.
// Rows and expanse keep their tuned drafts in every set. Unknown maps use set 0.
#include <cambc.h>
#include "draft.h"
#include "params.h"
#include "mapid.h"
#include <algorithm>
#include <vector>
#ifndef P_DRAFT_SET
#define P_DRAFT_SET 0
#endif
#ifndef P_DRAFT_DBG
#define P_DRAFT_DBG 0
#endif
#if P_DRAFT_DBG
#include <iostream>
#endif

using D = cambc::champion_draft;

namespace {

using mapid::MapId;

int set_for(MapId id) {
    switch (id) {
#ifdef P_SET_MONOLITH
        case MapId::monolith: return P_SET_MONOLITH;
#endif
#ifdef P_SET_CONTEST
        case MapId::contest: return P_SET_CONTEST;
#endif
#ifdef P_SET_ELKRING
        case MapId::elkring: return P_SET_ELKRING;
#endif
#ifdef P_SET_FRAGMENT
        case MapId::fragment: return P_SET_FRAGMENT;
#endif
#ifdef P_SET_COLLISION
        case MapId::collision_old: case MapId::collision_v2: return P_SET_COLLISION;
#endif
#ifdef P_SET_CORNERS
        case MapId::corners_old: case MapId::corners_v2: return P_SET_CORNERS;
#endif
#ifdef P_SET_INTERLOCK
        case MapId::interlock_old: case MapId::interlock_v2: return P_SET_INTERLOCK;
#endif
#ifdef P_SET_LANES
        case MapId::lanes_old: case MapId::lanes_v2: return P_SET_LANES;
#endif
#ifdef P_SET_PACKS
        case MapId::packs_old: case MapId::packs_v2: return P_SET_PACKS;
#endif
#ifdef P_SET_EIGHT
        case MapId::eight: return P_SET_EIGHT;
#endif
#ifdef P_SET_AMBUSH
        case MapId::ambush: return P_SET_AMBUSH;
#endif
#ifdef P_SET_PILGRIMAGE
        case MapId::pilgrimage: return P_SET_PILGRIMAGE;
#endif
#ifdef P_SET_RUSHBAIT
        case MapId::rushbait: return P_SET_RUSHBAIT;
#endif
#ifdef P_SET_STAMPEDE
        case MapId::stampede: return P_SET_STAMPEDE;
#endif
#ifdef P_SET_SWIRL
        case MapId::swirl: return P_SET_SWIRL;
#endif
        case MapId::unknown: return 0;
        default: return P_DRAFT_SET;
    }
}

const D CI = D::cassi_and_issac, REN = D::ren, ST = D::stellar, RY = D::ryth, VA = D::varg,
        TA = D::tavi, VE = D::vendetta, PR = D::prism;

// Template lists. Rows and expanse are not listed: they keep the v4.18b drafts.
std::vector<D> template_prefs(MapId id, int set) {
    const bool one = (set == 1);
    switch (id) {
        case MapId::collision_old: case MapId::collision_v2:
            return one ? std::vector<D>{CI, REN, ST} : std::vector<D>{PR, REN, ST};
        case MapId::packs_old: case MapId::packs_v2:
            return one ? std::vector<D>{CI, REN, ST} : std::vector<D>{CI, ST, VA};
        case MapId::fragment:
            return one ? std::vector<D>{CI, REN, ST} : std::vector<D>{CI, ST, VA};
        case MapId::interlock_old: case MapId::interlock_v2:
            return one ? std::vector<D>{CI, REN, RY, ST} : std::vector<D>{CI, REN, ST, TA};
        case MapId::swirl: case MapId::rushbait:
            return one ? std::vector<D>{CI, REN, RY, ST} : std::vector<D>{CI, ST, VA, REN};
        case MapId::corners_old: case MapId::corners_v2:
            return one ? std::vector<D>{CI, REN, RY, ST, VA} : std::vector<D>{PR, REN, RY, ST, TA};
        case MapId::elkring: case MapId::lanes_old: case MapId::lanes_v2:
            return one ? std::vector<D>{CI, REN, RY, ST, VA} : std::vector<D>{CI, REN, ST, TA, VA};
        case MapId::monolith:
            return one ? std::vector<D>{CI, REN, RY, ST, VA} : std::vector<D>{CI, REN, RY, VA, VE};
        case MapId::eight:
            return one ? std::vector<D>{CI, REN, RY, ST, VA} : std::vector<D>{CI, ST, VA, REN, TA};
        case MapId::stampede: case MapId::contest:
            return one ? std::vector<D>{CI, PR, REN, ST, TA} : std::vector<D>{CI, ST, VA, REN, RY};
        case MapId::ambush: case MapId::pilgrimage:
            return std::vector<D>{CI, REN, RY, ST, VA};
        default:
            return {};
    }
}

// The shipped v4.18b selection, unchanged.
std::vector<D> legacy_prefs() {
    const auto size = cambc::draft::team_size();
    const std::vector<D> small{D::vendetta, D::cassi_and_issac, D::stellar, D::ryth, D::varg, D::tavi};
    const std::vector<D> large{D::vendetta, D::cassi_and_issac, D::varg, D::ryth, D::tavi, D::ren, D::marcella, D::stellar};
    std::vector<D> rows_prefs{D::cassi_and_issac, D::varg, D::tavi, D::stellar, D::ryth, D::vendetta};
    bool rows = false;
    try { if (P_ROWS_CMD && cambc::map::width() == 50 && cambc::map::height() == 50) {
        int packs = 0; bool elk = false;
        for (auto g : cambc::map::camp_groups()) {
            int w = 0;
            for (const auto& c : g.camps()) { if (c.is_elk()) elk = true; if (c.is_wolf()) ++w; }
            if (w >= 3) ++packs;
        }
        rows = !elk && packs == 6;
    } } catch (...) { rows = false; }
    const std::vector<D> il_prefs{D::vendetta, D::varg, D::ryth, D::tavi, D::ren, D::marcella, D::stellar};
    bool il = false;
    try { il = P_IL_DRAFT && size == 4 && cambc::map::width() == 40 && cambc::map::height() == 40; } catch (...) { il = false; }
    const std::vector<D> scr_prefs{D::cassi_and_issac, D::stellar, D::varg, D::vendetta, D::cassi_and_issac, D::varg, D::ryth, D::tavi, D::stellar, D::ren};
    bool scr = false;
    try { scr = !rows && size == 3 && cambc::map::width() == 31 && cambc::map::height() == 31; } catch (...) { scr = false; }
    const std::vector<D> runner_prefs{D::vendetta, D::cassi_and_issac, D::varg};
    bool run = false;
    try { run = P_RUNNER && !rows && size == 3 && cambc::map::width() == 80 && cambc::map::height() == 80; } catch (...) { run = false; }
    return run ? runner_prefs : rows ? rows_prefs : (scr ? scr_prefs : (il ? il_prefs : (size <= 3 ? small : large)));
}

} // namespace

void play_draft() {
    const auto mine = cambc::draft::current_draft(cambc::team::ally);
    std::vector<D> prefs;
    MapId id = MapId::unknown;
    int set = 0;
    try {
        id = mapid::current_map();
        set = set_for(id);
        if (set != 0) prefs = template_prefs(id, set);
    } catch (...) { prefs.clear(); set = 0; }
    if (prefs.empty()) { set = 0; prefs = legacy_prefs(); }
#if P_DRAFT_DBG
    std::cout << "DRAFT map " << mapid::map_name(id) << " set " << set << " picks " << cambc::draft::team_size() << " order";
    for (auto p : prefs) std::cout << " " << static_cast<int>(p);
    std::cout << "\n" << std::flush;
#endif
    for (auto pick : prefs)
        if (std::find(mine.begin(), mine.end(), pick) == mine.end()) { cambc::draft::pick(pick); return; }
    for (int i = 0; i < 11; ++i) {
        auto pick = static_cast<D>(i);
        if (std::find(mine.begin(), mine.end(), pick) == mine.end()) { cambc::draft::pick(pick); return; }
    }
}
