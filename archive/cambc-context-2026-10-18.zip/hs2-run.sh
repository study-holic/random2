#!/bin/bash
WS="C:/Users/willi/OneDrive/Desktop/cambc-context"; CTX="$WS/cambc-context"
export PATH="$PATH:/c/Users/willi/AppData/Roaming/Python/Python313/Scripts" CAMBC_OFFLINE=1
cd "$WS" && cp -r cambc-context/bots/v5-base/src/* bots/sw-hostile/src/ && printf '#define P_OPENING_ASSIGN 1\n#define P_HOSTILE 1\n' > bots/sw-hostile/src/params_override.h && cambc build sw-hostile 2>&1 | tail -1
rm -rf replays/hs2; mkdir -p replays/hs2; sed 's|replays/hs/|replays/hs2/|' hs.txt > hs2.txt
echo "=== games $(wc -l < hs2.txt) $(date +%H:%M)"; cambc run-batch hs2.txt --jobs 2 2>&1 | tail -1
cd "$CTX" && python tools/replay/arm_eval.py "$WS/replays/hs2" sw-hostile 2>&1 | tail -30
echo "HS2DONE $(date +%H:%M)"
