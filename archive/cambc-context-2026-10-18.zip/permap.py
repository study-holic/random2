import json,sys,collections
d=json.load(open(sys.argv[1])); m=collections.defaultdict(list)
for c in d['cells']: m[c['map']].append((c['cand']['gp100']-c['base']['gp100'],c['base']['gp100'],c['cand']['end']-c['base']['end'],c['cand']['deaths']-c['base']['deaths']))
for k in sorted(m):
    v=m[k]; b=sum(x[1] for x in v)/len(v); dd=sum(x[0] for x in v)/len(v)
    print(k,len(v),'base %.1f d %+.2f (%+.1f%%) changed %d dEnd %+.0f dDeaths %+.2f'%(b,dd,100*dd/b,sum(1 for x in v if abs(x[0])>1e-9),sum(x[2] for x in v)/len(v),sum(x[3] for x in v)/len(v)))
