#!/usr/bin/env python3
"""Draft-set round-robin with a decision rule fixed before any game is played.

Usage (from the cambc workspace root):
    python roundrobin.py --bots s0 s1 s2 --maps "maps/*.map26a" --out rr

s0 must be the live controller with P_DRAFT_SET 0 (identical to v4.18b's draft);
s1 and s2 the same controller with P_DRAFT_SET 1 and 2. Every pair plays every map
on both sides. Rows and expanse are skipped: every set drafts them identically.

Decision rule (pre-registered 18 Oct 2026; do not edit after the first game):
  A candidate set c in {1, 2} replaces set 0 on a map when
    standard maps: c beats s0 head-to-head 2-0 AND c's round-robin wins >= s0's;
    weak maps (live ranked z <= -2: corners, elkring, interlock, packs, swirl, eight):
        c wins at least 1 of 2 head-to-head games AND c's round-robin wins > s0's.
  If both candidates qualify: more round-robin wins, then larger summed gem margin, then set 1.
  Otherwise the map keeps set 0.
The script prints P_SET_<MAP> lines for params_override.h. Apply them as printed.
"""
import argparse, csv, glob, hashlib, itertools, os, re, subprocess, sys

# sha256 prefixes of the 17 files supplied on 16 Oct, plus the six originals (evidence 05.2).
HASH = {
    "50365c961d1f8523": "rows", "61bcbc25b93c8009": "monolith", "c76debb1c6fde9ba": "contest",
    "37b8ace8d2ae29b8": "elkring", "9696d12821252abe": "fragment", "61fa921a44a47442": "eight",
    "cd0e19ffcbaaea59": "ambush", "13843d1e38afd731": "pilgrimage", "c84673dd8ca2d199": "rushbait",
    "43362dd0d8b404f2": "stampede", "988f7804a0f3e3fa": "swirl",
    "ebfcace19ebb3bca": "collision", "ee68ccad568ca8ff": "corners", "95a4e64280dfd13f": "expanse",
    "c7ac699781ace755": "interlock", "bf50fd858a0f4d89": "lanes", "116b2c569baf13bb": "packs",
    "688199fc0e7673fb": "collision", "35a749b76bf756c0": "corners", "62630c258647621e": "expanse",
    "a6556f1fe2eb02d8": "interlock", "322914beda81d0a3": "lanes", "d6b390d394e698db": "packs",
}
FIXED = {"rows", "expanse"}
WEAK = {"corners", "elkring", "interlock", "packs", "swirl", "eight"}
WIN = re.compile(r"Team ([AB]) \((.+?)\) wins")
ROW = re.compile(r"^\s+([AB])\s+(\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)")


def map_name(path):
    h = hashlib.sha256(open(path, "rb").read()).hexdigest()[:16]
    return HASH.get(h, os.path.splitext(os.path.basename(path))[0])


def play(a, b, path, outdir):
    cmd = ["cambc", "run", a, b, "--map", path, "-o", outdir]
    r = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "CAMBC_OFFLINE": "1"})
    text = r.stdout + r.stderr
    m = WIN.search(text)
    gems = {}
    for line in text.splitlines():
        g = ROW.match(line)
        if g:
            gems[g.group(1)] = (int(g.group(3)), int(g.group(5)))  # gems, deaths
    if not m or len(gems) < 2:
        raise RuntimeError("could not parse result for %s vs %s on %s:\n%s" % (a, b, path, text[-800:]))
    return m.group(1), gems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bots", nargs=3, required=True, help="bots for sets 0, 1, 2")
    ap.add_argument("--maps", required=True)
    ap.add_argument("--out", default="rr")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    sets = {0: args.bots[0], 1: args.bots[1], 2: args.bots[2]}
    rows = []
    for path in sorted(glob.glob(args.maps)):
        name = map_name(path)
        if name in FIXED:
            continue
        for x, y in itertools.combinations(sets, 2):
            for a, b in ((x, y), (y, x)):
                winner, gems = play(sets[a], sets[b], path, os.path.join(args.out, "replays"))
                rows.append(dict(map=name, A=a, B=b, winner=a if winner == "A" else b,
                                 gemsA=gems["A"][0], gemsB=gems["B"][0], deathsA=gems["A"][1], deathsB=gems["B"][1]))
                print(name, "A=s%d B=s%d winner=s%d gems %d-%d" % (a, b, rows[-1]["winner"], gems["A"][0], gems["B"][0]), flush=True)
    with open(os.path.join(args.out, "games.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    print("\nmap        s0w s1w s2w  h2h(1v0) h2h(2v0)  choice")
    overrides = []
    for name in sorted({r["map"] for r in rows}):
        R = [r for r in rows if r["map"] == name]
        wins = {s: sum(1 for r in R if r["winner"] == s) for s in sets}
        margin = {s: sum((r["gemsA"] - r["gemsB"]) if r["A"] == s else (r["gemsB"] - r["gemsA"])
                         for r in R if s in (r["A"], r["B"])) for s in sets}
        h2h = {c: sum(1 for r in R if {r["A"], r["B"]} == {0, c} and r["winner"] == c) for c in (1, 2)}
        qual = []
        for c in (1, 2):
            if name in WEAK:
                ok = h2h[c] >= 1 and wins[c] > wins[0]
            else:
                ok = h2h[c] == 2 and wins[c] >= wins[0]
            if ok:
                qual.append(c)
        choice = 0
        if qual:
            choice = sorted(qual, key=lambda c: (-wins[c], -margin[c], c))[0]
        print("%-10s %3d %3d %3d  %8d %8d  set %d" % (name, wins[0], wins[1], wins[2], h2h[1], h2h[2], choice))
        overrides.append("#define P_SET_%s %d" % (name.upper(), choice))
    print("\n// paste into params_override.h of the release build")
    print("\n".join(overrides))
    open(os.path.join(args.out, "params_override_draft.h"), "w").write("\n".join(overrides) + "\n")


if __name__ == "__main__":
    sys.exit(main())
