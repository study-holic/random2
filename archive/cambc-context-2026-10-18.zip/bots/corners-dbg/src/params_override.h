// v4.14 = v4.13 + opening assignment on maps with 5+ qualifying groups (expanse); EXP-083
#define P_OPENING_ASSIGN 1
#define P_CORNERS_DBG 1
#define P_CORNERS_DBG_ROUNDS 220
