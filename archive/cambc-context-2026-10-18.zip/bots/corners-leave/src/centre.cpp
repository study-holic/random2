// EXP-104 corners centre loop. Corners (71x71, mirrored in x) has eight gem clusters around the centre altar (35,34): pairs of
// 24 gems. Detection and setup run only on 71x71 maps (init_corners); every other entry is gated by cw_unit, false elsewhere.
// Three collector units (strongest damage dealers; Cassi and Issac count as one) go to the centre set from round 1, attack the
// nearest living cluster, the nearest collector captures a cleared pair, tributes at the centre altar from P_CORNERS_BAG gems and
// holds within 3 tiles of the group that is ready first. The hold never stands on a camp spawn tile (an occupied spawn tile delays
// the whole group respawn). Retreat, enemy response, banking walk and everything else are the v4-15 flow (a copy of play_turn).
#include <cambc.h>
#include "bot.h"
#include "util.h"
#include "params.h"
#include <algorithm>
#include <array>
#include <cstdint>
#include <span>
#include <variant>
#include <vector>
#if P_CORNERS_DBG
#include <iostream>
#endif

using cambc::vec2;
using cambc::team;
using CT = cambc::champion_type;

static constexpr float kRetreatHurt = P_RETREAT_HURT, kRetreatCalm = P_RETREAT_CALM, kRetreatTank = P_RETREAT_TANK;
static constexpr float kRecallDoneField = P_RECALL_DONE_FIELD, kRecallDoneSpawn = P_RECALL_DONE_SPAWN, kSpawnLeaveHp = P_SPAWN_LEAVE_HP;
static constexpr int kNearSpawn = P_NEAR_SPAWN;

static int unit_score(CT t) {   // level-1 basic-attack strength (docs/derived/engine-truth.md champion table)
    switch (t) {
        case CT::vendetta: return 70;
        case CT::ryth: return 52;
        case CT::varg: return 50;
        case CT::marcella: return 45;
        case CT::issac: return 40;
        case CT::ren: return 40;
        case CT::stellar: case CT::prism: return 35;
        case CT::cassi: return 30;
        default: return 35;
    }
}

namespace {
struct BlockGuard {   // restores a bitboard when the scope ends, also on an exception
    cambc::bitboard& ref;
    cambc::bitboard saved;
    explicit BlockGuard(cambc::bitboard& r) : ref(r), saved(r) {}
    ~BlockGuard() { ref = saved; }
};
}

void Bot::init_corners() {
    int best_n = 0;
    vec2 best_a(0, 0);
    for (auto a : cambc::map::altars().positions()) {
        int n = 0;
        for (const auto& g : groups) {
            if (!g.has_gem_cluster) continue;
            for (const auto& c : g.group.camps()) if (c.is_gem_cluster() && tile_distance(c.spawn_position(), a) <= 3) ++n;
        }
        if (n > best_n) { best_n = n; best_a = a; }
    }
    if (best_n < 6) return;
    cw_is.assign(groups.size(), 0);
    cw_resp.assign(groups.size(), 0);
    cw_probe.assign(groups.size(), -1000);
    cw_groups.clear();
    for (std::size_t i = 0; i < groups.size(); ++i) {
        if (groups[i].monolith || !groups[i].has_gem_cluster) continue;
        for (const auto& c : groups[i].group.camps())
            if (c.is_gem_cluster() && tile_distance(c.spawn_position(), best_a) <= 3) { cw_is[i] = 1; break; }
        if (cw_is[i]) cw_groups.push_back(static_cast<int>(i));
    }
    if (cw_groups.empty()) return;
    cw_on = true;
    cw_altar = best_a;
    struct Unit { int score = 0; int first = 99; std::vector<int> members; };
    std::vector<Unit> units;
    int cassi_i = -1, issac_i = -1, me_i = -1;
    for (std::size_t i = 0; i < roster.size(); ++i) {
        const CT t = roster[i].champion_name();
        if (roster[i] == cambc::self()) me_i = static_cast<int>(i);
        if (t == CT::cassi) cassi_i = static_cast<int>(i);
        else if (t == CT::issac) issac_i = static_cast<int>(i);
        else { Unit u; u.score = unit_score(t); u.first = static_cast<int>(i); u.members.push_back(static_cast<int>(i)); units.push_back(u); }
    }
    if (cassi_i >= 0 || issac_i >= 0) {   // the pair is one unit
        Unit u;
        if (cassi_i >= 0) { u.score += unit_score(CT::cassi); u.members.push_back(cassi_i); u.first = std::min(u.first, cassi_i); }
        if (issac_i >= 0) { u.score += unit_score(CT::issac); u.members.push_back(issac_i); u.first = std::min(u.first, issac_i); }
        units.push_back(u);
    }
    std::stable_sort(units.begin(), units.end(), [](const Unit& a, const Unit& b) { return a.score != b.score ? a.score > b.score : a.first < b.first; });
    cw_roster_unit.assign(roster.size(), 0);
    for (std::size_t k = 0; k < units.size() && static_cast<int>(k) < P_CORNERS_UNITS; ++k)
        for (int m : units[k].members) cw_roster_unit[m] = 1;
    cw_issac = (issac_i >= 0 && cassi_i >= 0 && cw_roster_unit[issac_i]) ? issac_i : -1;
    cw_unit = me_i >= 0 && cw_roster_unit[me_i];
    if (P_CORNERS_EXCL && !cw_unit)   // post-hoc variant: the rest leave the centre set to the collectors
        for (int gi : cw_groups) groups[gi].excluded_until = 1 << 30;
#if P_CORNERS_DBG
    if (ally_index == 0) {
        std::cout << "CW init altar " << best_a.x << "," << best_a.y << " clusters" << best_n << " groups" << groups.size() << " centre";
        for (int gi : cw_groups) {
            std::cout << " [g" << gi << " gems" << groups[gi].gems << " tiles";
            for (auto t : groups[gi].tiles) std::cout << " " << t.x << "," << t.y;
            std::cout << "]";
        }
        std::cout << " roster";
        for (std::size_t i = 0; i < roster.size(); ++i) std::cout << " " << static_cast<int>(roster[i].champion_name()) << (cw_roster_unit[i] ? "*" : "");
        std::cout << " issac" << cw_issac << std::endl;
    }
#endif
}

// 0 alive, 1 reward available (cleared, capture needed), 2 respawning (ready_round set), -1 not probed (fuel or error).
int Bot::probe_centre(int gi, int round) {
    if (cambc::fuel_remaining() < 45000) return -1;
    cw_probe[gi] = round;
    try {
        const auto st = groups[gi].group.state();
        if (auto r = std::get_if<cambc::map::camp_group_respawning>(&st)) {
            groups[gi].ready_round = round + r->timer;
            cw_resp[gi] = 1;
#if P_CORNERS_DBG
            std::cout << "PROBE r" << round << " g" << gi << " respawning timer" << r->timer << " a" << ally_index << std::endl;
#endif
            return 2;
        }
        groups[gi].ready_round = 0;
        const bool reward = std::get_if<cambc::map::camp_group_reward_available>(&st) != nullptr;
#if P_CORNERS_DBG
        std::cout << "PROBE r" << round << " g" << gi << (reward ? " reward" : " alive") << " a" << ally_index << std::endl;
#endif
        return reward ? 1 : 0;
    } catch (...) { return -1; }
}

TurnView Bot::build_view_centre() const {   // build_view with every centre group read out to 8 tiles
    TurnView v;
    v.pos = cambc::self().position();
    v.round = static_cast<int>(cambc::round_number());
    v.visible = cambc::vision::visible_tiles();
    const cambc::bitboard near = tiles_around(v.pos, 4) & v.visible;
    for (std::size_t i = 0; i < groups.size(); ++i) {
        const auto& g = groups[i];
        if (g.ready_round > v.round) continue;
        const bool focus = (is_squad_group(static_cast<int>(i)) && (static_cast<int>(i) == target || static_cast<int>(i) == holding)) || cw_is[i];
        const int reach = focus ? 8 : 4;
        if (min_distance(v.pos, g.tiles) > reach) continue;
        const auto& area = focus ? v.visible : near;
        for (const auto& c : g.group.camps())
            if (area.is_set(c.spawn_position()) && c.is_visible()) {
                const float h = c.health();
                if (h > 0) v.camps.push_back({c, static_cast<int>(i), h});
            }
    }
    return v;
}

// Sets target / holding / cw_wait / cw_active. False hands the turn to the v4-15 target flow (no centre group ready soon).
bool Bot::resolve_centre(const TurnView& v, const std::vector<cambc::champion>& allies) {
    auto& me = cambc::self();
    const int round = v.round;
    cw_active = false;
    cw_wait = false;
    std::array<std::uint8_t, 8> mem{};
    cambc::shared_memory.read(0, std::span{mem.data(), mem.size()});
    if (holding >= 0) {   // a capture in progress: stand on a spawn tile until the group respawns (paid) or 20 rounds pass
        bool alive = false;
        for (const auto& c : v.camps) if (c.group == holding) alive = true;
        refresh_group(holding, round, v.visible);
        const bool paid = alive || groups[holding].ready_round > round;
        if (paid || round - hold_since > 20) {
#if P_CORNERS_DBG
            std::cout << "PAID r" << round << " g" << holding << " a" << ally_index << " paid" << paid << " ready" << groups[holding].ready_round
                      << " held" << (round - hold_since) << " gems" << me.gem_count() << std::endl;
#endif
            if (!paid) groups[holding].ready_round = round + P_CORNERS_RESPAWN;
            cw_resp[holding] = 1;
            holding = -1;
            target = -1;
        } else { target = holding; cw_active = true; return true; }
    }
    int best = -1, best_d = 1 << 20, soon = -1, soon_ready = 1 << 20, pending = -1, pending_d = 1 << 20;
    bool probed = false;
    auto note_soon = [&](int gi) { if (groups[gi].ready_round < soon_ready) { soon_ready = groups[gi].ready_round; soon = gi; } };
    for (int gi : cw_groups) {
        auto& g = groups[gi];
        const int d = min_distance(v.pos, g.tiles);
        if (g.ready_round > round) { note_soon(gi); continue; }
        int live = 0;
        for (const auto& c : v.camps) if (c.group == gi) ++live;
        if (live > 0) {
            if (cw_resp[gi]) {
                cw_resp[gi] = 0;
#if P_CORNERS_DBG
                std::cout << "ALIVE r" << round << " g" << gi << " a" << ally_index << std::endl;
#endif
            }
            if (d < best_d) { best_d = d; best = gi; }
            continue;
        }
        if (!(d <= 8 && (g.mask & ~v.visible).is_empty())) {   // not in full view: presumed alive
            if (d < best_d) { best_d = d; best = gi; }
            continue;
        }
        if (probed || round - cw_probe[gi] < 2) { if (d < pending_d) { pending_d = d; pending = gi; } continue; }
        probed = true;
        const int s = probe_centre(gi, round);   // cleared and in full view: reward waiting, or respawning
        if (s == 1) {   // the nearest collector (ties: lower roster index) captures
            int bd = d, bi = ally_index;
            for (const auto& a : allies) {
                if (!a.is_visible()) continue;
                const int idx = roster_index(a);
                if (idx < 0 || a == me || !a.is_alive() || !cw_roster_unit[idx]) continue;
                const int dd = min_distance(a.position(), g.tiles);
                if (dd > 4) continue;
                if (dd < bd || (dd == bd && idx < bi)) { bd = dd; bi = idx; }
            }
            if (bi == ally_index) { holding = gi; hold_since = round; target = gi; cw_active = true; return true; }
            g.ready_round = round + 6;   // a mate is capturing it
            note_soon(gi);
            continue;
        }
        if (s == 0) { if (d < best_d) { best_d = d; best = gi; } continue; }
        if (s == -1) g.ready_round = round + 4;
        note_soon(gi);
    }
    if (best >= 0 && me.champion_name() == CT::cassi && cw_issac >= 0) {   // Cassi and Issac move as one unit
        const int f = static_cast<int>(mem[std::min(cw_issac, kSquadClaimByte - 1)]) - 1;
        if (f >= 0 && f < static_cast<int>(cw_is.size()) && cw_is[f] && groups[f].ready_round <= round) best = f;
    }
    if (best >= 0) { target = best; cw_active = true; return true; }
    if (pending >= 0) { target = pending; cw_wait = true; cw_active = true; return true; }
    if (soon >= 0 && soon_ready - round <= P_CORNERS_STAY) {
        if (!probed && round - cw_probe[soon] >= 6) probe_centre(soon, round);   // the estimate may be long
        target = soon; cw_wait = true; cw_active = true;
        return true;
    }
    return false;
}

void Bot::farm_centre(const TurnView& v) {
    auto& me = cambc::self();
    if (holding >= 0) {   // capture: stand on a spawn tile until the group respawns
        if (!groups[holding].mask.is_set(v.pos)) move_towards_closest(static_block, camp_static, groups[holding].mask);
        return;
    }
    if (target < 0) return;
    const int rng = std::max(1, static_cast<int>(me.attack_range()));
    if (cw_wait) {   // hold within 3 tiles of the group, never on a camp spawn tile
        cambc::bitboard goals; goals.clear();
        for (const auto& t : groups[target].tiles) goals |= tiles_around(t, 3);
        goals &= ~camp_static;
        goals &= ~static_block;
        if (!goals.is_set(v.pos)) move_towards_closest(static_block, camp_static, goals);
        return;
    }
    const LiveCamp* prey = nullptr;   // a camp in reach (lowest health), else the nearest live centre camp
    int pd = 1 << 20; float ph = 0.0f; bool pin = false;
    for (const auto& c : v.camps) {
        if (!cw_is[c.group]) continue;
        const int d = tile_distance(v.pos, c.camp.spawn_position());
        const bool in = d <= rng;
        if (prey == nullptr || (in && !pin) || (in == pin && (in ? c.health < ph : (d < pd || (d == pd && c.health < ph))))) {
            prey = &c; pd = d; ph = c.health; pin = in;
        }
    }
    if (prey == nullptr) {   // nothing in view yet: approach the group
        if (!groups[target].ring.is_set(v.pos)) move_towards_closest(static_block, camp_static, groups[target].ring);
        return;
    }
    target = prey->group;
    const vec2 pp = prey->camp.spawn_position();
    if (tile_distance(v.pos, pp) > rng || camp_static.is_set(v.pos)) {   // in reach, and off every spawn tile
        cambc::bitboard goals = tiles_around(pp, rng) & ~camp_static & ~static_block;
        move_towards_closest(static_block, camp_static, goals);
    }
    try {
        if (cast_on_camp(prey->camp)) { attack_if_in_range(prey->camp); return; }
        if (attack_if_in_range(prey->camp)) { reset_and_attack_again(prey->camp); return; }
    } catch (...) { return; }   // the camp died this turn (engine error 97)
    for (const auto& c : v.camps) {
        if (!cw_is[c.group]) continue;
        try { if (attack_if_in_range(c.camp)) { reset_and_attack_again(c.camp); return; } } catch (...) {}
    }
}

void Bot::play_turn_centre() {
    auto& me = cambc::self();
    update_stuck();
    could_attack = me.is_alive() && me.can_attack();
    {   // the spawn tiles of respawning centre groups are obstacles for the whole turn, goals included (an occupied spawn tile delays the whole group respawn)
        BlockGuard guard(static_block);
        const int rnd0 = static_cast<int>(cambc::round_number());
        for (int gi : cw_groups) if (gi != holding && groups[gi].ready_round > rnd0) static_block |= groups[gi].mask;
        play_turn_inner_centre();
    }
    attacked = could_attack && me.is_alive() && !me.can_attack();
    std::uint8_t mine = me.is_alive() ? static_cast<std::uint8_t>(target + 1) : 0;
    cambc::shared_memory.write(ally_index, std::span<const std::uint8_t>{&mine, 1});
#if P_CORNERS_DBG
    {
        const int rnd = static_cast<int>(cambc::round_number());
        if (me.is_alive()) {
            const auto p = me.position();
            for (int gi : cw_groups)
                if (groups[gi].mask.is_set(p) && groups[gi].ready_round > rnd)
                    std::cout << "ONTILE r" << rnd << " a" << ally_index << " g" << gi << " ready" << groups[gi].ready_round << std::endl;
            if (rnd <= P_CORNERS_DBG_ROUNDS)
                std::cout << "T r" << rnd << " a" << ally_index << " " << static_cast<int>(me.champion_name()) << " " << p.x << "," << p.y << " tg" << target
                          << " hold" << holding << " wait" << cw_wait << " act" << cw_active << " bank" << banking << " gems" << me.gem_count()
                          << " hp" << static_cast<int>(me.health()) << " fuel" << cambc::fuel_remaining() << std::endl;
        }
    }
#endif
}

// A copy of Bot::play_turn_inner (v4-15) with the centre target flow, the 24-gem tribute and no stuck detector while holding.
void Bot::play_turn_inner_centre() {
    auto& me = cambc::self();
    if (!me.is_alive()) { buy_items(); holding = -1; retreating = false; banking = false; bank_spawn_done = false; regrouping = false; bag_fled = false; cw_wait = false; cw_active = false; return; }
    if (me.is_submitting_gems()) was_submitting = true;
    if (me.is_recalling() || me.is_submitting_gems() || me.is_teleporting()) return;
    const bool tribute_done = was_submitting && me.gem_count() == 0;
    was_submitting = false;

    if (P_OPENING_ASSIGN && me.gem_count() > 0) open_done = true;
    const TurnView v = build_view_centre();
    update_group_memory(v);
    note_mixed_clusters(v);
    for (int gi : cw_groups)   // never stand on the spawn tile of a respawning centre group
        if (gi != holding && groups[gi].mask.is_set(v.pos) && groups[gi].ready_round > v.round) {
            move_towards_closest(static_block, camp_static, tiles_around(v.pos, 1) & ~camp_static & ~static_block);
            break;
        }
    const bool at_spawn = ally_spawn.is_set(v.pos);
    if (at_spawn || (P_FIELD_SHOP && remote_shop)) buy_items();
    if (!me.can_move() && !me.can_attack()) return;
    if (at_spawn && me.health() < me.max_health() * kSpawnLeaveHp) return;
    if (cw_wait) still_rounds = 0;   // holding beside a respawning group is not stuck
    else if (handle_stuck(v)) return;

    cast_shield(v);

    auto enemies = cambc::vision::champions(team::enemy);
    auto allies = cambc::vision::champions(team::ally);
    update_contested(v, enemies);
    const bool enemies_near = !enemies.empty();
    float threshold = (me.gem_count() > 0 || enemies_near) ? kRetreatHurt : kRetreatCalm;
    if (engaged_at_squad_target(v)) threshold = std::max(threshold, kRetreatTank);
    const double incoming = incoming_damage(v, v.pos);
    if (P_SHOP_RECALL && tribute_done && !at_spawn && incoming == 0 && min_distance(v.pos, spawn_tiles) >= P_SHOP_RECALL_ALTAR_DIST) {
        bool foe8 = false;
        for (const auto& e : enemies) if (tile_distance(e.position(), v.pos) <= 8) foe8 = true;
        const bool can_shop = me.gold_count() >= cambc::item_type::monster_shard_of_strength.cost();
        if (!foe8 && (can_shop || me.health() < me.max_health() * 0.9f)) { try { me.recall(); } catch (...) {} return; }
    }
    double need = std::max<double>(me.max_health() * threshold, incoming * P_RETREAT_INCOMING_MULT + P_RETREAT_INCOMING_BASE * me.max_health());
    if (!at_spawn && me.health() < need) { retreating = true; holding = -1; }
    if (retreating && (at_spawn ? me.health() >= me.max_health() * kRecallDoneSpawn : me.health() >= me.max_health() * kRecallDoneField)) retreating = false;
    if (retreating && v.pos == pos_prev2 && !(v.pos == pos_prev)) ++retreat_osc;
    else if (!(v.pos == pos_prev2)) retreat_osc = 0;
    if (retreat_osc >= 4) { retreat_walk_until = v.round + 40; retreat_osc = 0; }
    pos_prev2 = pos_prev; pos_prev = v.pos;
    if (retreating && !at_spawn) {
        if (min_distance(v.pos, spawn_tiles) <= kNearSpawn && move_towards_closest(static_block, camp_static, ally_spawn)) return;
        if (incoming > 0) {
            if (v.round < retreat_walk_until && move_towards_closest(static_block, camp_static, ally_spawn)) return;
            if (move_towards_closest(static_block, camp_static, ~danger_zone(v))) return;
        } else if (!enemies_near) { me.recall(); return; }
        else { move_towards_closest(static_block, camp_static, ally_spawn); return; }
    }

    if (P_THREAT_LAYER) {
        allies6 = 0;
        for (const auto& a : allies) if (!(a == me) && tile_distance(v.pos, a.position()) <= 6) ++allies6;
        if (threat_layer(v, enemies, allies)) return;
    }
    if (me.gem_count() >= static_cast<unsigned>(P_CORNERS_BAG) && holding < 0 && !retreating) banking = true;   // tribute at the centre altar from 24 gems
    if (banking && me.gem_count() > 0)
        for (auto altar : altars)
            if (tile_distance(v.pos, altar) <= cambc::constants::submit_gems_range) { if (bank(v, enemies, allies)) return; break; }
    if (enemy_response(v, enemies, allies)) return;
    if (P_ALLY_VISION_FIX) { keep_visible(enemies); keep_visible(allies); }

    if (!at_spawn && enemies_near && me.health() < me.max_health() * threshold) {
        move_towards_closest(static_block, camp_static, ally_spawn);
        return;
    }

    bool cw_leave = false;   // EXP-108: hand the turn back to the v4-15 flow while enemies at the centre are at least as many as ours
    if (P_CORNERS_LEAVE) {
        static int leave_until = -1;
        int en = 0, al = 0;
        for (const auto& e : enemies) if (tile_distance(e.position(), cw_altar) <= 6) ++en;
        for (const auto& a : allies) if (tile_distance(a.position(), cw_altar) <= 6) ++al;
        if (en > 0 && en >= al) leave_until = v.round + 10;
        cw_leave = v.round < leave_until;
    }
    if (cw_leave) { holding = -1; cw_wait = false; cw_active = false; resolve_target(v, allies); }
    else if (!resolve_centre(v, allies)) { cw_active = false; resolve_target(v, allies); }
    if (me.gem_count() >= static_cast<unsigned>(P_CORNERS_BAG) && holding < 0) banking = true;
    if (bank(v, enemies, allies)) return;
    if (cw_active) farm_centre(v); else farm(v, allies);
}
