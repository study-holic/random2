#!/bin/bash
WS="C:/Users/willi/OneDrive/Desktop/cambc-context"; CTX="$WS/cambc-context"
export PATH="$PATH:/c/Users/willi/AppData/Roaming/Python/Python313/Scripts" CAMBC_OFFLINE=1
cd "$CTX" && echo "=== identity $(date +%H:%M)" && python tools/identity_check.py v5-base 2>&1 | tail -5
cd "$WS" && mkdir -p bots/sw-hostile && cp -r cambc-context/bots/v5-base/src bots/sw-hostile/ && printf '#define P_OPENING_ASSIGN 1\n#define P_HOSTILE 1\n' > bots/sw-hostile/src/params_override.h && cambc build sw-hostile 2>&1 | tail -1
mkdir -p replays/hs && : > hs.txt
for o in v4-3a v4-8; do for m in 41 40 31 71; do echo "bots/sw-hostile bots/$o maps/map$m.map26a replays/hs/sw-hostile_vs_${o}_m${m}_A.repl26a" >> hs.txt; echo "bots/$o bots/sw-hostile maps/map$m.map26a replays/hs/${o}_vs_sw-hostile_m${m}_B.repl26a" >> hs.txt; done; done
for m in 71 30 40; do echo "bots/sw-hostile bots/hunter maps/map$m.map26a replays/hs/sw-hostile_vs_hunter_m${m}_A.repl26a" >> hs.txt; echo "bots/hunter bots/sw-hostile maps/map$m.map26a replays/hs/hunter_vs_sw-hostile_m${m}_B.repl26a" >> hs.txt; done
for m in 71 80; do echo "bots/sw-hostile bots/starter-cpp maps/map$m.map26a replays/hs/sw-hostile_vs_starter-cpp_m${m}_A.repl26a" >> hs.txt; echo "bots/starter-cpp bots/sw-hostile maps/map$m.map26a replays/hs/starter-cpp_vs_sw-hostile_m${m}_B.repl26a" >> hs.txt; done
echo "=== games $(wc -l < hs.txt) $(date +%H:%M)"; cambc run-batch hs.txt --jobs 2 2>&1 | tail -2
cd "$CTX" && python tools/replay/arm_eval.py "$WS/replays/hs" sw-hostile 2>&1 | tail -30
echo "HSDONE $(date +%H:%M)"
